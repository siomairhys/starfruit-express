import { motion } from "framer-motion";
import { sources } from "@/data/siteContent";
import { SectionHeading } from "./WhySection";
import { ExternalLink } from "lucide-react";

export function DesignNotes() {
  return (
    <section id="notes" className="relative py-20 lg:py-28 bg-cream-warm/50">
      <div className="mx-auto max-w-[1280px] px-5 md:px-8">
        <SectionHeading
          eyebrow="Design Rationale"
          title={
            <>
              An evolution of the real <em className="font-500 not-italic">Starfruit Express</em>, not a replacement.
            </>
          }
          lede="Every section here maps directly back to the live website. The work below documents what was preserved, the opportunity identified, the design decision, and the intended improvement."
        />

        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {sources.map((s, i) => (
            <motion.article
              key={s.id}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="rounded-3xl border border-line bg-cream p-6 md:p-7"
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-mono text-[0.6rem] uppercase tracking-wider text-citrus-deep">Section 0{i + 1}</p>
                  <h3 className="mt-1 font-display text-xl font-700 text-forest-deep">{s.title}</h3>
                </div>
                <a
                  href={s.originalUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 rounded-full border border-line px-2.5 py-1 text-[0.65rem] font-mono uppercase tracking-wider text-ink-soft hover:border-forest-deep/30 hover:text-forest-deep"
                >
                  Source <ExternalLink className="h-3 w-3" />
                </a>
              </div>
              <p className="mt-3 text-sm text-ink-soft">
                <span className="font-semibold text-forest-deep">Original page · </span>
                {s.originalPage} — {s.originalPurpose}
              </p>
              <div className="mt-4 grid gap-3 sm:grid-cols-2">
                <Block label="Preserved" tone="leaf">
                  <ul className="space-y-1">
                    {s.preserved.map((p) => (
                      <li key={p} className="text-sm text-forest-deep">• {p}</li>
                    ))}
                  </ul>
                </Block>
                <Block label="Opportunity" tone="citrus">
                  <p className="text-sm text-forest-deep">{s.opportunity}</p>
                </Block>
              </div>
              <div className="mt-3 rounded-2xl border border-forest-deep/15 bg-forest-deep text-cream p-4">
                <p className="font-mono text-[0.6rem] uppercase tracking-wider text-citrus">Decision</p>
                <p className="mt-1 text-sm leading-relaxed">{s.decision}</p>
                <p className="mt-3 font-mono text-[0.6rem] uppercase tracking-wider text-cream/60">Intended improvement</p>
                <p className="mt-1 text-sm leading-relaxed text-cream/85">{s.improvement}</p>
              </div>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}

function Block({ label, tone, children }: { label: string; tone: "leaf" | "citrus"; children: React.ReactNode }) {
  const cls =
    tone === "leaf"
      ? "border-leaf/25 bg-leaf/8"
      : "border-citrus-deep/25 bg-citrus/10";
  const tx = tone === "leaf" ? "text-leaf" : "text-citrus-deep";
  return (
    <div className={`rounded-2xl border ${cls} p-4`}>
      <p className={`font-mono text-[0.6rem] uppercase tracking-wider ${tx}`}>{label}</p>
      <div className="mt-1">{children}</div>
    </div>
  );
}
