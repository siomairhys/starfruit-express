export const nav = [
  { label: "Overview", href: "#overview" },
  { label: "Why Starfruit", href: "#why" },
  { label: "Purchasing", href: "#purchasing" },
  { label: "Fulfillment", href: "#fulfillment" },
  { label: "Assessment", href: "#assessment" },
  { label: "Design Notes", href: "#notes" },
];

export const contact = {
  phone: "(786) 305-7470",
  phoneHref: "tel:+17863057470",
  email: "fresh@starfruitexpress.com",
  hours: "Mon – Fri · 9:00 AM – 7:00 PM",
  region: "Florida",
};

export interface SectionSource {
  id: string;
  title: string;
  originalPage: string;
  originalUrl: string;
  originalPurpose: string;
  preserved: string[];
  opportunity: string;
  decision: string;
  improvement: string;
}

export const sources: SectionSource[] = [
  {
    id: "hero",
    title: "Homepage Hero",
    originalPage: "Home",
    originalUrl: "https://www.starfruitexpress.com/",
    originalPurpose:
      "Frame Starfruit Express as a partner that helps restaurants uncover hidden profits and reduce operational stress.",
    preserved: [
      "‘Time is Money. We Save You Both.’ positioning",
      "Restaurant-operator audience",
      "Purchasing + fulfillment dual identity",
      "Citrus-and-forest brand palette",
    ],
    opportunity:
      "Opportunity to surface operational value above the fold by pairing the editorial promise with a live-feeling glimpse of the product.",
    decision:
      "Split hero with an editorial headline on the left and an illustrative operations card on the right that previews an actual restaurant order.",
    improvement:
      "Operators understand what Starfruit actually does within three seconds, not three scrolls — and the dual purchasing + fulfillment story becomes visible immediately.",
  },
  {
    id: "why",
    title: "Traditional vs. Starfruit",
    originalPage: "Home — Operational Friction",
    originalUrl: "https://www.starfruitexpress.com/",
    originalPurpose:
      "Show the chaos of a typical restaurant Tuesday — texts from reps, scattered spreadsheets, last-minute substitutions — and contrast it with Starfruit’s calmer system.",
    preserved: [
      "‘What does your typical Tuesday look like?’ premise",
      "Multiple-supplier, multi-channel reality",
      "Empathetic, operator-first tone",
    ],
    opportunity:
      "Opportunity to strengthen hierarchy by replacing the loose chat-window collage with a side-by-side workflow comparison that reads in seconds.",
    decision:
      "A two-column ‘before / after’ workflow with labeled nodes — fragmented suppliers on the left, one coordinated system on the right.",
    improvement:
      "The business argument is legible at a glance and works equally well on mobile, where the columns stack into sequential cards.",
  },
  {
    id: "purchasing",
    title: "Purchasing Intelligence",
    originalPage: "Home — Solutions / Profits",
    originalUrl: "https://www.starfruitexpress.com/solutions",
    originalPurpose:
      "Communicate that Starfruit gives operators visibility into supplier pricing, rebates, and missed margin recovery.",
    preserved: [
      "Purchasing visibility theme",
      "Supplier comparison and rebate awareness",
      "‘We only get paid when you profit’ trust",
    ],
    opportunity:
      "Opportunity to improve product storytelling — the original describes purchasing benefits in prose; a real interface communicates them faster.",
    decision:
      "A handcrafted purchasing dashboard concept showing a real restaurant comparing two suppliers on a single SKU with rebate status and price history.",
    improvement:
      "Operators see exactly how the platform would feel, raising perceived product maturity and supporting the sales conversation.",
  },
  {
    id: "fulfillment",
    title: "Cold-Chain Fulfillment",
    originalPage: "Contact — Why Choose Us",
    originalUrl: "https://www.starfruitexpress.com/contact",
    originalPurpose:
      "Reassure operators that Starfruit delivers in temperature-controlled vehicles with a responsive operations team.",
    preserved: [
      "Temperature-controlled fulfillment promise",
      "Fast-response operations identity",
      "Florida-focused delivery footprint",
    ],
    opportunity:
      "Opportunity to improve visual storytelling around fulfillment — the value is currently a short bullet, not a felt experience.",
    decision:
      "An interactive five-stage delivery timeline with live-feeling temperature and ETA telemetry, horizontal on desktop and vertical on mobile.",
    improvement:
      "Cold-chain reliability becomes tangible. Operators see a delivery they can follow, not simply hope for.",
  },
  {
    id: "assessment",
    title: "Savings Assessment",
    originalPage: "Contact — Send a Message",
    originalUrl: "https://www.starfruitexpress.com/contact",
    originalPurpose:
      "Convert restaurant operators into a conversation with the Starfruit team via a generic contact form.",
    preserved: [
      "Verified phone, email, and business hours",
      "‘Useful first, business second’ tone",
      "Florida service region",
    ],
    opportunity:
      "Opportunity to simplify the decision path — replace a generic contact form with an assessment framed around what operators are actually buying.",
    decision:
      "A three-step Savings Assessment with a polished client-side form, inline validation, an explicit success state, and clear concept labelling.",
    improvement:
      "The CTA finally matches the promise of the headline, raising intent and qualifying leads with structured restaurant context.",
  },
];
